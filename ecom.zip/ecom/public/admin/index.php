<?php require_once("../../resources/config.php"); ?>
<?php require_once(TEMPLATE_BACK . "/header.php"); ?>
<?php

    if(!isset($_SESSION['username'])){
        redirect('../../public');
    }

?>

<div id="page-wrapper">

    <div class="container-fluid">



        <?php

    if($_SERVER['REQUEST_URI']== "/ecom/public/admin/" || $_SERVER['REQUEST_URI']== "/ecom/public/admin/index.php"){
        include_once(TEMPLATE_BACK . "/admin_content.php");
    }
    if(isset($_GET['orders'])){
        include_once(TEMPLATE_BACK . "/orders.php");
    }
    if(isset($_GET['view_products'])){
        include_once(TEMPLATE_BACK . "/products.php");
    }
    if(isset($_GET['add_products'])){
        include_once(TEMPLATE_BACK . "/add_product.php");
    }
    if(isset($_GET['edit_product'])){
        include_once(TEMPLATE_BACK . "/edit_product.php");
    }
    if(isset($_GET['categories'])){
        include_once(TEMPLATE_BACK . "/categories.php");
    }
    if(isset($_GET['users'])){
        include_once(TEMPLATE_BACK . "/users.php");
    }
    if(isset($_GET['add_user'])){
        include_once(TEMPLATE_BACK . "/add_user.php");
    }
    if(isset($_GET['edit_user'])){
        include_once(TEMPLATE_BACK . "/edit_user.php");
    }
    if(isset($_GET['reports'])){
        include_once(TEMPLATE_BACK . "/reports.php");
    }
?>


    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->



<?php require_once(TEMPLATE_BACK . "/footer.php"); ?>
<?php require_once("../resources/config.php"); ?>
<?php include(TEMPLATE_FRONT .  "/header.php");?>
<?php processTransaction() ?>

    <!-- Page Content -->
    <div class="container">

        <h1 class="text-center">Thank You</h1>

    </div>

<?php include(TEMPLATE_FRONT .  "/footer.php");?>
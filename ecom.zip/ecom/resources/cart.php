<?php require_once("config.php"); ?>

<?php

    if(isset($_GET['add'])){ 
        $add_id=escapeString($_GET['add']);

        $result=query("SELECT * FROM products WHERE product_id={$add_id}");
        confirmQuery($result);

        while($row=fetchArray($result)){
            $product_quantity=$row['product_quantity'];
            $product_title=$row['product_title'];
            if($product_quantity != $_SESSION['product_' . $add_id]){
                $_SESSION['product_' . $add_id] +=1 ;
                redirect('../public/checkout.php');
            }else{
                setMessage("We only have " . $product_quantity . " " . $product_title ." available"); 
                redirect("../public/checkout.php");
            }
        }
    }

    if(isset($_GET['remove'])){
        $remove_id=escapeString($_GET['remove']);

        $_SESSION['product_' . $remove_id]--;

        if($_SESSION['product_' . $remove_id]<1){
            unset ($_SESSION['item_total']);
            unset ($_SESSION['item_quantity']);
            redirect('../public/checkout.php');
        }else{
            redirect('../public/checkout.php');
        }
    }

    if(isset($_GET['delete'])){
        $delete_id=escapeString($_GET['delete']);
        $_SESSION['product_' . $delete_id]='0';
        unset ($_SESSION['item_total']);
        unset ($_SESSION['item_quantity']);
        redirect('../public/checkout.php');
    }


    function cart(){

        $total=0;
        $item_quantity=0;
        $item_name= 1;
        $item_number=1;
        $amount=1;
        $quantity=1;

        foreach ($_SESSION as $name => $value){

            if($value > 0){

                if(substr($name, 0, 8) == "product_" ){

                    $length = strlen($name );

                    $id= escapeString(substr($name, 8, $length));

                    $result=query("SELECT * FROM products WHERE product_id={$id}");
                    confirmQuery($result);
    
                    while($row=fetchArray($result)){
                        $product_id=$row['product_id'];
                        $product_title=$row['product_title'];
                        $product_price=$row['product_price'];
                        $product_image=$row['product_image'];
                        $product_quantity=$row['product_quantity'];

                        $img_path=displayImage($product_image);

                        $sub=$product_price * $value;
                        $item_quantity+=$value;

    
                        //heradoc... acting like "" when u already have "" in your text/ we have nowdoc that act like ''//
                        $product = <<<DELIMETER
                                    <tr>
                                        <td>{$product_title}</td>
                                        <td>
                                        <img width='100px' src='../resources/{$img_path}'>
                                        </td>
                                        <td>&#36;{$product_price}</td>
                                        <td>{$value}</td>
                                        <td>&#36;{$sub}</td>
                                        <td>
                                            <a class='btn btn-warning' href="../resources/cart.php?remove={$product_id}"><span class='glyphicon glyphicon-minus'></span></a>
                                            <a class='btn btn-success' href="../resources/cart.php?add={$product_id}"><span class='glyphicon glyphicon-plus'></span></a>
                                            <a class='btn btn-danger' href="../resources/cart.php?delete={$product_id}"><span class='glyphicon glyphicon-remove'></span></a>
                                        </td>
                                    </tr>
                                    <input type="hidden" name="item_name_{$item_name}" value="{$product_title}"> 
                                    <input type="hidden" name="item_number_{$item_number}" value="{$product_id}"> 
                                    <input type="hidden" name="amount_{$amount}" value="{$product_price}">
                                    <input type="hidden" name="quantity_{$quantity}" value="{$value}">
                                    DELIMETER;
                        echo $product;

                        $item_name++;
                        $item_number++;
                        $amount++;
                        $quantity++;

                    }
                    $_SESSION['item_total']=$total+=$sub;
                    $_SESSION['item_quantity']=$item_quantity;

                }
            }
        } 
    }

    function showPaypal(){

        if(isset($_SESSION['item_quantity']) && $_SESSION['item_quantity'] >=1){
           $paypal_button=<<<DELIMETER
                            <input type="image" name="upload" border="0" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" alt="PayPal - The safer, easier way to pay online">
                            DELIMETER;
           return $paypal_button;
        }
    }



    function processTransaction(){
       

        if(isset($_GET['tx'])){
            $amount      = escapeString($_GET['amt']);
            $currency    = escapeString($_GET['cc']);
            $transaction = escapeString($_GET['tx']);
            $status      = escapeString($_GET['st']);
    
            $total=0;
            $item_quantity=0;
        

            foreach ($_SESSION as $name => $value){

                if($value > 0){

                    if(substr($name, 0, 8) == "product_" ){

                        $length = strlen($name );

                        $id= escapeString(substr($name, 8, $length));

                        $send_order=query("INSERT INTO orders SET
                                order_amount='{$amount}',
                                order_currency='{$currency}',
                                order_transaction='{$transaction}',
                                order_status='{$status}'
                        ");
                        $last_id=lastId();
                        confirmQuery($send_order);

                        $result=query("SELECT * FROM products WHERE product_id={$id}");
                        confirmQuery($result);
        
                        while($row=fetchArray($result)){
                            $product_id=$row['product_id'];
                            $product_price=$row['product_price'];
                            $product_title=$row['product_title'];


                            $sub=$product_price * $value;
                            $item_quantity+=$value;

                            $insert_reports=query("INSERT INTO reports SET
                                    product_id='{$product_id}',
                                    product_title ='{$product_title}',
                                    order_id='{$last_id}',
                                    product_price='{$product_price}',
                                    product_quantity='{$value}'
                            ");
                            confirmQuery($insert_reports);
                        }
                        $total+=$sub;
                        $item_quantity;
                    }
                }
            } 
            session_destroy();
        }else{
             redirect("index.php");
        }
    }


?>
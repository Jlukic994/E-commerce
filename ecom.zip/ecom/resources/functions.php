<?php
$upload_directory="uploads";
////////////////////////////////////////////////HELPER FUNCTIONS/////////////////////////////////////////////////////

/***********************************REDIRECT TO SPECIFIC PAGE AFTER OPERATION*****************************************/
    function redirect($location){
        header("Location: $location");
    }
/***********************************EXECUTING QUERY*****************************************/
    function query($sql){
        global $conn;
        return mysqli_query($conn, $sql);
    }
/***********************************CHECKING QUERY*****************************************/
    function confirmQuery($result){
        global $conn;
        if(!$result){
            die("Query Failed!!" . mysqli_error($conn));
        }
    }
/***********************************AGAINST MYSQL INJECTION*****************************************/
    function escapeString($string){
        global $conn;
        return mysqli_real_escape_string($conn, $string);
    }
    
/***********************************FETCHING ARRAY IN WHILE LOOP*****************************************/
    function fetchArray($result){
        return mysqli_fetch_array($result);
    }

/***********************************SETTING SESSION MESSAGE*****************************************/
    function setMessage($msg){
        if(!empty($msg)){
            $_SESSION['message']=$msg;
        }else{
            $msg="";
        }
    }   
/***********************************DISPLAYING SESSION MESSAGE*****************************************/
    function displayMessage(){
        if(isset($_SESSION['message'])){
            echo $_SESSION['message'];
            unset ($_SESSION['message']);
        }
    }

/***********************************CHECKING FOR LAST ADDED ID IN DATABASE*****************************************/
    function lastId(){
        global $conn;
        return mysqli_insert_id($conn);

    }


/***********************************DIRECTORY FOR UPLOADED IMAGES*****************************************/
    function displayImage($img){
        global $upload_directory;
        return $upload_directory . DS . $img;
    }
   

////////////////////////////////////////////////FRONTEND FUNCTIONS/////////////////////////////////////////////////////
    
/****************************************DISPLAY PRODUCTS ON INDEX - MAIN PAGE************************************/
    function getProducts(){

        $result=query("SELECT * FROM products");
        confirmQuery($result);

        while($row=fetchArray($result)){
            $product_id=$row['product_id'];
            $product_title=$row['product_title'];
            $product_category_id=$row['product_category_id'];
            $product_price=$row['product_price'];
            $product_description=substr($row['product_description'], 0,80);
            $short_description=substr($row['short_desc'], 0,80);
            $product_image=$row['product_image'];

            $img_path=displayImage($product_image);

            //heradoc... acting like "" when u already have "" in your text/ we have nowdoc that act like ''//
            $product = <<<DELIMETER

                        <div class="col-sm-4 col-lg-4 col-md-4">
                            <div class="thumbnail">
                            <a href="item.php?id={$product_id}"><img src="../resources/$img_path" alt=""></a>
                                <div class="caption">
                                    <h4 class="pull-right">&#36;{$product_price}</h4>
                                    <h4><a href="item.php?id={$product_id}">{$product_title}</a>
                                    </h4>
                                    <p>{$short_description}...</p>
                                    <a class="btn btn-primary" href="../resources/cart.php?add={$product_id}">Add to cart</a>
                                </div>
                                
                            </div>
                        </div>

                        DELIMETER;
            echo $product;
        }
    }


/****************************************DISPLAY CATEGORIES ON SIDE NAVIGATION************************************/
    function getCategories(){
        global $conn;
        $result=query("SELECT * FROM categories");
        confirmQuery($result);
        
        while($row=fetchArray($result)){
            $cat_id=$row['cat_id'];
            $cat_title=$row['cat_title'];

            $categorLinks = <<<DELIMETER
                        <a href='category.php?id={$cat_id}' class='list-group-item'>{$cat_title}</a>
                        DELIMETER;

        echo $categorLinks;

        }
    }




/****************************************DISPLAY PRODUCTS FOR SPECIFIC CATEGORY************************************/
    function displayProductForCategory(){
        global $conn;

        if(isset($_GET['id'])){
            $category_id=escapeString($_GET['id']);
        }
        $result=query("SELECT * FROM products WHERE product_category_id={$category_id}");
        confirmQuery($result);
        $count=mysqli_num_rows($result);
        if($count==0) echo"<h1 class='text-center text-danger'>No Products In This Category Right Now</h1>";
        
        while($row=fetchArray($result)){
            $product_id=$row['product_id'];
            $product_title=$row['product_title'];
            $product_category_id=$row['product_category_id'];
            $product_price=$row['product_price'];
            $product_description=substr($row['product_description'], 0,80);
            $short_description=substr($row['short_desc'], 0,70);
            $product_image=$row['product_image'];

            $img_path=displayImage($product_image);

            $products_for_cat = <<<DELIMETER
                        <div class="col-md-3 col-sm-6 hero-feature">
                            <div class="thumbnail">
                                <img src="../resources/{$img_path}" alt="">
                                <div class="caption">
                                    <h3>{$product_title}</h3>
                                    <p>{$short_description}...</p>
                                
                                        <a href="../resources/cart.php?add={$product_id}" class="btn btn-primary">Buy Now!</a> 
                                        <a href="item.php?id={$product_id}" class="btn btn-default">More Info</a>
                                    
                                </div>
                                <br>
                                <br>
                            </div>
                        </div>
                        DELIMETER;
            
            echo $products_for_cat;
        }
    }

/****************************************DISPLAY PRODUCTS IN SHOP PAGE************************************/
    function get_products_in_shop_page(){
        global $conn;

        if(isset($_GET['id'])){
            $category_id=escapeString($_GET['id']);
        }
        $result=query("SELECT * FROM products");
        confirmQuery($result);
        $count=mysqli_num_rows($result);
        if($count==0) echo"<h1 class='text-center text-danger'>No Products In This Category Right Now</h1>";
        
        while($row=fetchArray($result)){
            $product_id=$row['product_id'];
            $product_title=$row['product_title'];
            $product_category_id=$row['product_category_id'];
            $product_price=$row['product_price'];
            $product_description=substr($row['product_description'], 0,80);
            $short_description=substr($row['short_desc'], 0,70);
            $product_image=$row['product_image'];

            $img_path=displayImage($product_image);


            $products_for_cat = <<<DELIMETER
                        <div class="col-md-3 col-sm-6 hero-feature">
                            <div class="thumbnail">
                                <img src="../resources/{$img_path}" alt="">
                                <div class="caption">
                                    <h3>{$product_title}</h3>
                                    <p>{$short_description}...</p>
                                
                                        <a href="../resources/cart.php?add={$product_id}" class="btn btn-primary">Buy Now!</a> 
                                        <a href="item.php?id={$product_id}" class="btn btn-default">More Info</a>
                                    
                                </div>
                                <br>
                                <br>
                            </div>
                        </div>
                        DELIMETER;
            
            echo $products_for_cat;
        }
    }


/****************************************LOG IN USER************************************/
    function loginUser(){

        if(isset($_POST['submit'])){
            $username=escapeString($_POST['username']);
            $password=escapeString($_POST['password']);

            $result=query("SELECT * FROM users WHERE username='{$username}' AND password='{$password}'");
            confirmQuery($result);

            if(mysqli_num_rows($result) == 0){
                setMessage("Your Password or Username are wrong");
                redirect("login.php");
            }else{
                $_SESSION['username']=$username;
                redirect("admin");
            }
        }
    }


/****************************************SENDING MAIL FROM CONTACT US FORM************************************/
    function sendMessage(){
        if(isset($_POST['submit'])){
            $to      = "jankolukic994@gmail.com";
            $name    = $_POST['name'];
            $subject = $_POST['subject'];
            $email   = $_POST['email'];
            $message = $_POST['message'];

            $headers="From: {$name} {$email}";

            $result=@(mail($to, $subject, $message, $headers));

            if(!$result){
                setMessage("Sorry we could not send your message");
                redirect("contact.php");
            }else{
                setMessage("Your Message has been sent");
                redirect("contact.php");

            }
        }
    }


    
////////////////////////////////////////////////BACKEND FUNCTIONS/////////////////////////////////////////////////////

/****************************************DISPLAY ORDERS IN ADMIN************************************/
    function displayOrders(){

        $result=query("SELECT * FROM orders");
        confirmQuery($result);
        while($row=fetchArray($result)){
            $order_id=$row['order_id'];
            $order_amount=$row['order_amount'];
            $order_transaction=$row['order_transaction'];
            $order_currency=$row['order_currency'];
            $order_status=$row['order_status'];

            $orders=<<<DELIMETER
                        <tr>
                            <td>{$order_id}</td>
                            <td>{$order_amount}</td>
                            <td>{$order_transaction}</td>
                            <td>{$order_currency}</td>
                            <td>{$order_status}</td>
                            <td><a class='btn btn-danger' href="../../resources/tamplates/back/delete_order.php?delete={$order_id}"><span class='glyphicon glyphicon-remove'></span></a></td>
                        </tr>
                    DELIMETER;
            echo $orders;        
        }
    }


/****************************************DISPLAY PRODUCTS IN ADMIN************************************/
    function displayProductsInAdmin(){

        $result=query("SELECT * FROM products");
        confirmQuery($result);
        
        while($row=fetchArray($result)){
            $product_id=$row['product_id'];
            $product_title=$row['product_title'];
            $product_category_id=$row['product_category_id'];
            $product_price=$row['product_price'];
            $product_quantity=$row['product_quantity'];
            $product_image=$row['product_image'];

            $img_path=displayImage($product_image);


            $cat_title=showProductCat($product_category_id);

            //heradoc... acting like "" when u already have "" in your text/ we have nowdoc that act like ''//
            $product = <<<DELIMETER
                        <tr>
                            <td>{$product_id}</td>
                            <td>{$product_title}</td>  
                            <td>
                            <a href='index.php?edit_product&id={$product_id}'><img width='100px' src='../../resources/{$img_path}'></a>
                            </td>      
                            <td>{$cat_title}</td>
                            <td>&#36;{$product_price}</td>
                            <td>{$product_quantity}</td>
                            <td>
                                <a class='btn btn-danger' href="../../resources/tamplates/back/delete_product.php?delete={$product_id}"><span class='glyphicon glyphicon-remove'></span></a>
                            </td>
                        </tr>
                        DELIMETER;
            echo $product;
        }
    }
/****************************************DISPLAY CAT TITLE IN PRODUCTS IN ADMIN************************************/
    function showProductCat($product_category_id){
        $result=query("SELECT * FROM categories WHERE cat_id={$product_category_id}");
        confirmQuery($result);

        while($red=fetchArray($result)){
            $cat_title=$red['cat_title'];
            return $cat_title;
        }
    }


/****************************************ADD PRODUCTS IN ADMIN************************************/
    function addProducts(){
        if(isset($_POST['publish'])){

            $product_title       = escapeString($_POST['product_title']);
            $product_category_id = escapeString($_POST['product_category_id']);
            $product_price       = escapeString($_POST['product_price']);
            $product_quantity    = escapeString($_POST['product_quantity']);
            $product_description = escapeString($_POST['product_description']);
            $short_desc          = escapeString($_POST['short_desc']);

            $product_image       = $_FILES['file']['name'];
            $image_temp_location = $_FILES['file']['tmp_name'];

            move_uploaded_file($image_temp_location, UPLOAD_DIRECTORY . DS . $product_image);

            $add_product_query=query("INSERT INTO products SET
                product_title       = '{$product_title}',
                product_category_id = '{$product_category_id}',
                product_price       = '{$product_price}',
                product_quantity    = '{$product_quantity}',
                product_description = '{$product_description}',
                short_desc          = '{$short_desc}',
                product_image       = '{$product_image}'
            ");
            $last_id=lastId();
            confirmQuery($add_product_query);
            setMessage("New Product with id {$last_id} was Added");
            redirect("index.php?add_products");
        }
    }


/****************************************DISPLAY DYNAMIC CATEGORIES IN ADD PRODUCTS************************************/
    function selectCategories(){

        $result=query("SELECT * FROM categories");
        confirmQuery($result);

        while($row= fetchArray($result)){
            $cat_id=$row['cat_id'];  
            $cat_title=$row['cat_title'];   
             
            echo "<option value='$cat_id'>{$cat_title}</option>";
        }
    }

    /****************************************UPDATE PRODUCTS IN ADMIN************************************/
    function updateProduct(){

        if(isset($_POST['update'])){


            $product_title       = escapeString($_POST['product_title']);
            $product_category_id = escapeString($_POST['product_category_id']);
            $product_price       = escapeString($_POST['product_price']) ;
            $product_quantity    = escapeString($_POST['product_quantity']);
            $product_description = escapeString($_POST['product_description']);
            $short_desc          = escapeString($_POST['short_desc']) ;

            $product_image       = escapeString($_FILES['file']['name']);
            $image_temp_location = $_FILES['file']['tmp_name'];


            if(empty($product_image)){
                $get_pic=query("SELECT product_image FROM products WHERE product_id=" .escapeString($_GET['id']). " ");
                confirmQuery($get_pic);
   
                while($pic = fetchArray($get_pic)){
                    $product_image=$pic['product_image'];
                }
            }
            move_uploaded_file($image_temp_location, UPLOAD_DIRECTORY . DS . $product_image);


            $update_product_query=query("UPDATE  products SET  
                `product_title`      =  '{$product_title}' , 
                `product_category_id` = '{$product_category_id}' , 
                `product_price`       = '{$product_price}' , 
                `product_quantity`    = '{$product_quantity}' , 
                `product_description` = '{$product_description}' , 
                `short_desc`          = '{$short_desc}' , 
                `product_image`       = '{$product_image}'  
                WHERE product_id      ="   .escapeString($_GET['id']). " ");
           

            confirmQuery($update_product_query);
            setMessage("Product has been updated");
            redirect("index.php?view_products");
        }
    }

    /****************************************SHOW REPORTS IN ADMIN PAGE************************************/

    function showReport(){
        $result=query("SELECT * FROM reports");
        confirmQuery($result);
        
        while($row=fetchArray($result)){
            $report_id=$row['report_id'];
            $product_id=$row['product_id'];
            $order_id=$row['order_id'];
            $product_price=$row['product_price'];
            $product_title=$row['product_title'];
            $product_quantity=$row['product_quantity'];

            //heradoc... acting like "" when u already have "" in your text/ we have nowdoc that act like ''//
            $product = <<<DELIMETER
                        <tr>
                            <td>{$report_id}</td>
                            <td>{$product_id}</td>  
                            <td>{$order_id}</td>   
                            <td>{$product_title}</td>
                            <td>&#36;{$product_price}</td>
                            <td>{$product_quantity}</td>
                            <td>
                                <a class='btn btn-danger' href="../../resources/tamplates/back/delete_report.php?delete={$report_id}"><span class='glyphicon glyphicon-remove'></span></a>
                            </td>
                        </tr>
                        DELIMETER;
            echo $product;
        }
    }

    /****************************************SHOW CATEGORIES IN ADMIN PAGE************************************/

    function showCategoriesInAdmin(){
        
        $result=query("SELECT * FROM categories");
        confirmQuery($result);

        while($row=fetchArray($result)){
            $cat_id=$row['cat_id'];
            $cat_title=$row['cat_title'];

            $category = <<<DELIMETER
                    <tr>
                        <td>{$cat_id}</td>
                        <td>{$cat_title}</td>
                        <td>
                            <a class='btn btn-danger' href="../../resources/tamplates/back/delete_category.php?delete={$cat_id}"><span class='glyphicon glyphicon-remove'></span></a>
                        </td>
                    </tr>
            DELIMETER;
        echo $category;
        }
    }

    /****************************************ADD CATEGORIES IN ADMIN PAGE************************************/

    function addCategory(){
        if(isset($_POST['addCat'])){
            $cat_title=escapeString($_POST['cat_title']);

            if(empty($cat_title) || $cat_title== " "){
                setMessage("This cannot be empty");
            }else{
                $result=query("INSERT INTO categories SET cat_title='{$cat_title}'");
                confirmQuery($result);
                setMessage("New Category Added");
            }
        }
    }

    /****************************************DISPLAY USERS IN ADMIN PAGE************************************/

    function displayUsers(){
        
        $result=query("SELECT * FROM users");
        confirmQuery($result);

        while($row=fetchArray($result)){
            $user_id=$row['user_id'];
            $username=$row['username'];
            $email=$row['email'];
            $user_photo=$row['user_photo'];

            $img_path=displayImage($user_photo);


            $user = <<<DELIMETER
                    <tr>
                        <td>{$user_id}</td>
                        <td>
                            <a href='index.php?edit_user&id={$user_id}'><img class="img-circle" width='40px' src='../../resources/{$img_path}'></a>
                            </td> 
                        <td>{$username}</td>
                        <td>{$email}</td>
                        <td>
                            <a class='btn btn-danger' href="../../resources/tamplates/back/delete_user.php?delete={$user_id}"><span class='glyphicon glyphicon-remove'></span></a>
                        </td>
                    </tr>
            DELIMETER;
        echo $user;
        }
    }

     /****************************************ADD USER IN ADMIN PAGE************************************/

     function addUser(){
        if(isset($_POST['addUser'])){
            $username = escapeString($_POST['username']);
            $email    = escapeString($_POST['email']);
            $password = escapeString($_POST['password']);
            
            $user_photo=escapeString($_FILES['file']['name']);
            $photo_temp=$_FILES['file']['tmp_name'];

            move_uploaded_file($photo_temp, UPLOAD_DIRECTORY . DS . $user_photo );

            if(empty($username) || empty($email) || empty($password)){
                setMessage("Field cannot be empty");
            }else{
                $result=query("INSERT INTO users SET 
                            username='{$username}',
                            email='{$email}',
                            password='{$password}',
                            user_photo='{$user_photo}'
                            ");
                confirmQuery($result);
                setMessage("New User Added");
                redirect("index.php?users");
            }
        }
    }

     /****************************************UPDATE USER IN ADMIN PAGE************************************/

    function updateUser(){

        if(isset($_POST['updateUser'])){

            $username = escapeString($_POST['username']);
            $email    = escapeString($_POST['email']);
            $password = escapeString($_POST['password']);
            
            $user_photo=escapeString($_FILES['file']['name']);
            $photo_temp=$_FILES['file']['tmp_name'];


            if(empty($user_photo)){
                $get_pic=query("SELECT user_photo FROM users WHERE user_id=" .escapeString($_GET['id']). " ");
                confirmQuery($get_pic);
   
                while($pic = fetchArray($get_pic)){
                    $user_photo=$pic['user_photo'];
                }
            }
            move_uploaded_file($photo_temp, UPLOAD_DIRECTORY . DS . $user_photo);

            if(empty($username) || empty($email) || empty($password)){
                setMessage("Field cannot be empty");
            }else{
            $update_user=query("UPDATE  users SET  
                        username      = '{$username}',
                        email         = '{$email}',
                        password      = '{$password}',
                        user_photo    = '{$user_photo}'
                        WHERE user_id = " .escapeString($_GET['id']). " ");
           

            confirmQuery($update_user);
            setMessage("User has been updated");
            redirect("index.php?users");
            }
        }
    }

    
?>
<?php include_once("../../config.php");

    if(isset($_GET['delete'])){
        $id=escapeString($_GET['delete']);

        $result=query("DELETE FROM categories WHERE cat_id={$id}");
        confirmQuery($result);
        setMessage("Category successfully deleted!");
        redirect("../../../public/admin/index.php?categories");
    }else{
        redirect("../../../public/admin/index.php?categories");
    }

?>
<?php include_once("../../config.php");

    if(isset($_GET['delete'])){
        $id=escapeString($_GET['delete']);

        $result=query("DELETE FROM orders WHERE order_id={$id}");
        confirmQuery($result);
        setMessage("Order successfully deleted!");
        redirect("../../../public/admin/index.php?orders");
    }else{
        redirect("../../../public/admin/index.php?orders");
    }



?>
<?php include_once("../../config.php");

    if(isset($_GET['delete'])){
        $id=escapeString($_GET['delete']);

        $result=query("DELETE FROM products WHERE product_id={$id}");
        confirmQuery($result);
        setMessage("Product successfully deleted!");
        redirect("../../../public/admin/index.php?view_products");
    }else{
        redirect("../../../public/admin/index.php?view_products");
    }



?>
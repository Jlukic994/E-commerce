<?php include_once("../../config.php");

    if(isset($_GET['delete'])){
        $id=escapeString($_GET['delete']);

        $result=query("DELETE FROM reports WHERE report_id={$id}");
        confirmQuery($result);
        setMessage("Report successfully deleted!");
        redirect("../../../public/admin/index.php?reports");
    }else{
        redirect("../../../public/admin/index.php?reports");
    }



?>
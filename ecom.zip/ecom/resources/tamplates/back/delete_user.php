<?php include_once("../../config.php");

    if(isset($_GET['delete'])){
        $id=escapeString($_GET['delete']);

        $result=query("DELETE FROM users WHERE user_id={$id}");
        confirmQuery($result);
        setMessage("User successfully deleted!");
        redirect("../../../public/admin/index.php?users");
    }else{
        redirect("../../../public/admin/index.php?users");
    }



?>
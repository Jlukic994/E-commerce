
<?php  

  if(isset($_GET['id'])){

    $id=escapeString($_GET['id']);
  

    $getProduct=query("SELECT * FROM products WHERE product_id=$id");
    confirmQuery($getProduct);

    while($row=fetchArray($getProduct)){
      $product_id          = $row['product_id'];
      $product_title       = $row['product_title'];
      $product_category_id = $row['product_category_id'];
      $product_price       = $row['product_price'];
      $product_quantity    = $row['product_quantity'];
      $product_description = $row['product_description'];
      $short_desc          = $row['short_desc'];
      $product_image       = $row['product_image'];

      $img_path=displayImage($product_image);

    }
    updateProduct();
    // updateProduct();
  }

  ?>

    
<div class="col-md-12">

<div class="row">
<h1 class="page-header">
   Edit Product

</h1>

</div>
               

<form action="" method="post" enctype="multipart/form-data">


<div class="col-md-8">

<div class="form-group">
    <label for="product-title">Product Title </label>
        <input value="<?php echo $product_title; ?>" type="text" name="product_title"  class="form-control">
       
    </div>


    <div class="form-group">
           <label for="product-title">Product Description</label>
      <textarea name="product_description" id="" cols="30" rows="6" class="form-control"><?php echo $product_description; ?></textarea>
    </div>

    <div class="form-group">
           <label for="product-title">Short Description</label>
      <textarea name="short_desc" id="" cols="30" rows="4" class="form-control">  <?php echo $short_desc; ?></textarea>
    </div>

    <div class="form-group row">
      <div class="col-xs-3">
        <label for="product-title">Product Price</label>
        <input value="<?php echo $product_price;?>" type="number" name="product_price" class="form-control"  size="60">
      </div>
      
    </div>
    

</div><!--Main Content-->


<!-- SIDEBAR-->


<aside id="admin_sidebar" class="col-md-4">

     
     <div class="form-group">
       <input type="submit" name="draft" class="btn btn-warning btn-lg" value="Draft">
        <input type="submit" name="update" class="btn btn-primary btn-lg" value="Update">
    </div>


     <!-- Product Categories-->

    <div class="form-group">
         <label for="product-title">Product Category</label>
          <hr>
        <select name="product_category_id" id="" class="form-control">
            <option value="<?php $product_category_id; ?>"><?php echo showProductCat($product_category_id); ?></option>
            <?php selectCategories(); ?>
        </select>


</div>





    <!-- Product Quantity-->

    <div class="form-group">
        <label for="product-title">Product Quantity</label>
        <input value="<?php echo $product_quantity; ?>" type="number" name="product_quantity"  class="form-control" size="60">
    </div>


    <!-- Product Image -->
    <div class="form-group">
        <label for="product-title">Product Image</label>
        <input type="file" name="file"><br>
        <img width="220px" src="../../resources/<?php echo $img_path?>" alt="">
      
      </div>

      


  



</aside><!--SIDEBAR-->


    
</form>


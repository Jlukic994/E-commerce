
<?php  

if(isset($_GET['id'])){

  $id=escapeString($_GET['id']);


  $getUser=query("SELECT * FROM users WHERE user_id=$id");
  confirmQuery($getUser);

  while($row=fetchArray($getUser)){
            $user_id=$row['user_id'];
            $username=$row['username'];
            $email=$row['email'];
            $user_photo=$row['user_photo'];

            $img_path=displayImage($user_photo);

  }
  updateUser();
}

?>

<h1 class="page-header">
      Add User
      <small>Page</small>
  </h1>
  <h3 class="text-center bg-info"><?php displayMessage();?></h3>

<div class="col-md-6 user_image_box">

<?php 
    if(empty($user_photo)){
        echo "<span id='user_admin' class='img-circle fa fa-user fa-4x'></span> ";
    }else{
        echo "<img width='220px 'class='img-circle' src='../../resources/$img_path' alt=''>";
    }

?>
    
</div>


<form action="" method="post" enctype="multipart/form-data">

  <div class="col-md-6">

     <div class="form-group">
     
      <input type="file" name="file">
         
     </div>


     <div class="form-group">
      <label for="username">Username</label>
      <input type="text" name="username" class="form-control" value="<?php echo $username;?>" >
         
     </div>


      <div class="form-group">
          <label for="email">Email</label>
      <input type="text" name="email" class="form-control" value="<?php echo $email;?>"  >
         
     </div>

<!-- 
      <div class="form-group">
          <label for="first name">First Name</label>
      <input type="text" name="first_name" class="form-control"   >
         
     </div> -->
<!-- 
      <div class="form-group">
          <label for="last name">Last Name</label>
      <input type="text" name="last_name" class="form-control"   >
         
     </div> -->


      <div class="form-group">
          <label for="password">Password</label>
      <input type="password" name="password" class="form-control"  >
         
     </div>

      <div class="form-group">

      <a id="user-id" class="btn btn-danger" href="">Delete</a>

      <input type="submit" name="updateUser" class="btn btn-primary pull-right" value="Edit User" >
         
     </div>


      

  </div>



</form>





    
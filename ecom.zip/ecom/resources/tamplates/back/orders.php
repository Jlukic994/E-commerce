


        <div class="col-md-12">
<div class="row">
<h1 class="page-header">
   All Orders
</h1>
<h3 class="text-center bg-danger"><?php displayMessage();?></h3>
</div>

<div class="row">
<table class="table table-hover">
    <thead>

      <tr>
           <th>S.N</th>
           <th>Amount</th>
           <th>Transaction</th>
           <th>Currency</th>
           <th>Status</th>
      </tr>
    </thead>
    <tbody>
       <?php displayOrders();?> 
    </tbody>
</table>
</div>


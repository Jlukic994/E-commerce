

<div class="row">

    <h1 class="page-header">
    All Products
    </h1>
    <h3 class="text-center bg-info"><?php displayMessage();?></h3>
    <table class="table table-hover">


        <thead>

        <tr>
            <th>Id</th>
            <th>Title</th>
            <th>Image/Edit</th>
            <th>Category</th>
            <th>Price</th>
            <th>Quantity</th>
        </tr>
        </thead>
        <tbody>
        <?php displayProductsInAdmin();?>
        </tbody>
        </table>       

</div>

          